import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:flutter_chat_ui/flutter_chat_ui.dart';
import 'package:flutter_chat_types/flutter_chat_types.dart' as types;
import 'package:flutter_spinkit/flutter_spinkit.dart';

class Chatpage extends StatefulWidget {
  @override
  State<Chatpage> createState() => _ChatPageState();
}

class _ChatPageState extends State<Chatpage> {
  bool _isLoading = false;
  List<types.Message> _messages = [];
  final _user = const types.User(
    id: '82091008-a484-4a89-ae75-a22bf8d6f3ac',
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('ChatBot'),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              reverse: true,
              itemCount: _messages.length,
              itemBuilder: (BuildContext context, int index) {
                final message = _messages[index];
                return ChatMessage(
                  message: message,
                  showAvatar: message.author.id != _user.id,
                );
              },
            ),
          ),
          if (_isLoading)
            Center(
              child: SpinKitThreeBounce(
                color: Color(0xFF011158),
                size: 32.0,
              ),
            ),
        ],
      ),
      bottomNavigationBar: ChatInputToolbar(
        onSendPressed: _handleSendPressed,
      ),
    );
  }

  Future<void> _handleSendPressed(types.PartialText message) async {
    setState(() {
      _isLoading = true;
    });

    final textMessage = types.TextMessage(
      author: _user,
      createdAt: DateTime.now().millisecondsSinceEpoch,
      id: "id",
      text: message.text,
    );

    _addMessage(textMessage);
    try {
      final response = await _sendMessageToOpenAI(message.text);
      final List<dynamic> choices = response['choices'];
      for (final choice in choices) {
        final botReply = choice['message']['content'].trim();
        final botMessage = types.TextMessage(
          author: types.User(id: 'botId'),
          createdAt: DateTime.now().millisecondsSinceEpoch,
          id: UniqueKey().toString(),
          text: '$botReply',
        );

        _addMessage(botMessage);
      }
    } catch (e) {
      print('Error: $e');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<dynamic> _sendMessageToOpenAI(String message) async {
    final apiKey = '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';
    Map<String, String> headers = {
      'Authorization': 'Bearer $apiKey',
      'Content-Type': 'application/json',
    };

    List<Map<String, dynamic>> jsonList = [
      {'role': 'user', 'content': 'USER: $message'}
    ];

    Map<String, dynamic> params = {
      'model': 'gpt-3.5-turbo',
      'messages': jsonList,
      'temperature': 0.5,
    };

    var body = jsonEncode(params);

    final response = await http.post(
      Uri.parse('https://api.openai.com/v1/chat/completions'),
      headers: headers,
      body: body,
    );

    if (response.statusCode == 200) {
      Map<String, dynamic> responseBody = jsonDecode(response.body);
      return responseBody;
    } else {
      throw Exception(
          'Failed to send message to OpenAI: ${response.statusCode}');
    }
  }

  void _addMessage(types.Message message) {
    setState(() {
      _messages.insert(0, message);
    });
  }
}
